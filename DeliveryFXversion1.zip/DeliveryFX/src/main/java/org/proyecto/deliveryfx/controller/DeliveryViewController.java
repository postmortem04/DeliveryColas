package org.proyecto.deliveryfx.controller;

import javafx.collections.FXCollections; // Necesario para ObservableList
import javafx.collections.ObservableList; // Necesario para la TableView
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory; // Necesario para configurar TableView
import org.proyecto.deliveryfx.model.DeliveryModel; // Importa tu Modelo
import org.proyecto.deliveryfx.model.Pedido;       // Importa la clase Pedido
import org.proyecto.deliveryfx.model.Prioridad;    // Importa el enum Prioridad

import java.util.List; // Necesario para trabajar con listas
import java.util.UUID; // Necesario para generar IDs de pedido

public class DeliveryViewController {

    // Referencias a los elementos de la UI desde delivery-view.fxml
    @FXML
    private Button btnAgregarPedido;

    @FXML
    private Button btnProcesarSiguiente;

    @FXML
    // Especifica el tipo del ChoiceBox
    private ChoiceBox<Prioridad> choiceboxPrioridad;

    // Etiquetas (Labels) - Ya están bien con FXML
    @FXML private Label lblSubtitulo1;
    @FXML private Label lblSubtitulo2;
    @FXML private Label lblSubtitulo3;
    @FXML private Label lblSubtitulo4;
    @FXML private Label lblTituloGestion;
    @FXML private Label lblTituloPedido;
    @FXML private Label lblTituloProcesado;

    // TableView y sus columnas - Especifica el tipo Pedido
    @FXML
    private TableView<Pedido> tableviewPedidos;

    @FXML
    // Especifica el tipo de la columna (String para los atributos de Pedido)
    private TableColumn<Pedido, String> tablecolumnNombre;

    @FXML
    private TableColumn<Pedido, String> tablecolumnDireccion;

    @FXML
    private TableColumn<Pedido, String> tablecolumnDescrip;

    @FXML
    // La prioridad es un enum, pero TableColumn puede mostrar su String representation
    private TableColumn<Pedido, Prioridad> tablecolumnPrioridad;


    // Área de texto para mostrar el pedido procesado
    @FXML
    private TextArea textareaPedidoProcesado;

    // Campos de texto para agregar nuevos pedidos
    @FXML
    private TextField textfieldDescripcion;

    @FXML
    private TextField textfieldDireccion;

    @FXML
    private TextField textfieldNombre;


    // *** Referencia al Modelo de la aplicación ***
    private DeliveryModel deliveryModel;

    // ObservableList para mantener los datos de la TableView sincronizados
    private ObservableList<Pedido> pedidosEnColaObservableList;


    // Método llamado por HelloApplication para pasar la referencia al Modelo
    public void setDeliveryModel(DeliveryModel deliveryModel) {
        this.deliveryModel = deliveryModel;
        // Una vez que el modelo está disponible, podemos inicializar la vista que depende de él.
        // Podríamos llamar a cargarPedidosEnTabla() aquí o en initialize(), pero hacerlo
        // después de setDeliveryModel asegura que el modelo está listo.
        cargarPedidosEnTabla(); // Carga los pedidos existentes del modelo en la tabla
    }

    // Método initialize se llama automáticamente después de cargar el FXML
    @FXML
    public void initialize() {
        // 1. Configurar el ChoiceBox de Prioridad
        choiceboxPrioridad.getItems().setAll(Prioridad.values()); // Añade todas las opciones del enum
        choiceboxPrioridad.setValue(Prioridad.ESTANDAR); // Selecciona una opción por defecto

        // 2. Configurar la TableView y sus Columnas
        // Configura cómo cada columna obtiene el valor de un objeto Pedido
        tablecolumnNombre.setCellValueFactory(new PropertyValueFactory<>("cliente")); // Usa el nombre del getter sin "get"
        tablecolumnDireccion.setCellValueFactory(new PropertyValueFactory<>("direccion"));
        tablecolumnDescrip.setCellValueFactory(new PropertyValueFactory<>("descripcion"));
        tablecolumnPrioridad.setCellValueFactory(new PropertyValueFactory<>("prioridad")); // TableColumn<Pedido, Prioridad> usará toString() del enum por defecto

        // Inicializa la ObservableList que se vinculará a la TableView
        pedidosEnColaObservableList = FXCollections.observableArrayList();
        tableviewPedidos.setItems(pedidosEnColaObservableList);

        // Nota: cargarPedidosEnTabla() se llama después de setDeliveryModel()
        // para asegurar que deliveryModel no es null cuando se accede.
    }

    // Método para cargar o actualizar la TableView con los pedidos del Modelo
    private void cargarPedidosEnTabla() {
        if (deliveryModel != null) {
            // Obtiene la lista ordenada de pedidos del modelo
            List<Pedido> pedidosDelModelo = deliveryModel.getPedidosOrdenadosParaVista();
            // Limpia la lista observable y agrega los pedidos obtenidos
            pedidosEnColaObservableList.clear();
            pedidosEnColaObservableList.addAll(pedidosDelModelo);
            // Opcional: Imprimir el tamaño de la cola en consola para verificar
            System.out.println("TableView actualizada. Pedidos en cola: " + deliveryModel.getPedidosOrdenadosParaVista());
        } else {
            System.err.println("Error: DeliveryModel no está disponible para cargar pedidos en la tabla.");
        }
    }


    // *** Manejador del clic para el botón "Agregar Pedido" ***
    @FXML
    void OnAgregarPedidoButtonClick(ActionEvent event) {
        // 1. Obtener los datos de los campos de la UI
        String nombreCliente = textfieldNombre.getText().trim();
        String direccion = textfieldDireccion.getText().trim();
        String descripcion = textfieldDescripcion.getText().trim();
        Prioridad prioridadSeleccionada = choiceboxPrioridad.getValue(); // Obtiene el valor seleccionado del ChoiceBox

        // 2. Validar los datos (ejemplo básico)
        if (nombreCliente.isEmpty() || direccion.isEmpty() || descripcion.isEmpty() || prioridadSeleccionada == null) {
            mostrarMensajeError("Por favor, completa todos los campos y selecciona una prioridad.");
            return; // Detiene el proceso si falta información
        }

        // 3. Crear un nuevo objeto Pedido
        String idPedido = UUID.randomUUID().toString().substring(0, 8); // Genera un ID simple y único
        Pedido nuevoPedido = new Pedido(idPedido, nombreCliente, direccion, descripcion, prioridadSeleccionada, System.currentTimeMillis());

        // 4. Agregar el pedido al Modelo (a la cola de prioridad)
        if (deliveryModel != null) {
            deliveryModel.agregarPedido(nuevoPedido);

            // 5. Actualizar la Vista (la TableView) para reflejar el cambio
            cargarPedidosEnTabla(); // Vuelve a cargar los pedidos del modelo en la tabla

            // 6. Limpiar los campos de entrada después de agregar el pedido
            textfieldNombre.clear();
            textfieldDireccion.clear();
            textfieldDescripcion.clear();
            choiceboxPrioridad.setValue(Prioridad.ESTANDAR); // Restablecer la prioridad por defecto
            textareaPedidoProcesado.clear(); // Limpiar el área del último pedido procesado al agregar uno nuevo (opcional)

        } else {
            System.err.println("Error: DeliveryModel no está disponible para agregar el pedido.");
            mostrarMensajeError("Error interno: No se pudo agregar el pedido.");
        }
    }

    // *** Manejador del clic para el botón "Procesar Siguiente Pedido" ***
    @FXML
    void OnProcesarSigButtonClick(ActionEvent event) {
        // 1. Solicitar al Modelo que procese el siguiente pedido
        if (deliveryModel != null) {
            Pedido pedidoProcesado = deliveryModel.procesarSiguientePedido();

            // 2. Actualizar la Vista basándose en el resultado del Modelo
            if (pedidoProcesado != null) {
                // Mostrar los detalles del pedido procesado en el TextArea
                textareaPedidoProcesado.setText(
                        "ID: " + pedidoProcesado.getId() + "\n" +
                                "Cliente: " + pedidoProcesado.getCliente() + "\n" +
                                "Prioridad: " + pedidoProcesado.getPrioridad() + "\n" +
                                "Descripción: " + pedidoProcesado.getDescripcion()
                        // Podrías añadir más detalles si quieres
                );

                // Actualizar la TableView para reflejar que el pedido fue removido
                cargarPedidosEnTabla(); // Vuelve a cargar los pedidos restantes del modelo

            } else {
                // La cola estaba vacía, mostrar un mensaje en el TextArea
                textareaPedidoProcesado.setText("La cola de pedidos está vacía. No hay pedidos para procesar.");
                System.out.println("La cola de pedidos está vacía."); // También en consola
            }
        } else {
            System.err.println("Error: DeliveryModel no está disponible para procesar el pedido.");
            mostrarMensajeError("Error interno: No se pudo procesar el pedido.");
        }
    }

    // Método de ayuda para mostrar un mensaje de error en una alerta
    private void mostrarMensajeError(String mensaje) {
        javafx.scene.control.Alert alert = new javafx.scene.control.Alert(javafx.scene.control.Alert.AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText(null);
        alert.setContentText(mensaje);
        alert.showAndWait();
    }

    // Metodo de ayuda para mostrar un mensaje de información o éxito (opcional aquí)
    private void mostrarMensajeInfo(String mensaje) {
        javafx.scene.control.Alert alert = new javafx.scene.control.Alert(javafx.scene.control.Alert.AlertType.INFORMATION);
        alert.setTitle("Información");
        alert.setHeaderText(null);
        alert.setContentText(mensaje);
        alert.showAndWait();
    }
}